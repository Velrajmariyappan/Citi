from selenium import webdriver
import  unittest
import os
# for login amazon
class testsearch_(unittest.TestCase):
    driver= webdriver.Chrome(executable_path="C:\\Users\\chennai.support\\Downloads\\chromedriver.exe")
    driver.implicitly_wait(3)
    driver.get("https://www.amazon.in/ap/signin?_encoding=UTF8&ignoreAuthState=1&openid.assoc_handle=inflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fs%2Fref%3Dnav_signin%3Furl%3Dsearch-alias%253Daps%26field-keywords%3DGoogle%2BPixel%2B3%2BXL&switch_account=")
    driver.maximize_window()
    # credentials
    driver.find_element_by_id("ap_email").send_keys("dhrajeswari@gmail.com")
    driver.find_element_by_id("continue").click()
    driver.find_element_by_name("password").send_keys("shopping")
    driver.find_element_by_id("auth-signin-button").click()
    # search a product
    driver.find_element_by_id("twotabsearchtextbox").send_keys("Google Pixel 3 XL")
        # driver.find_elements_by_class_name("nav-input").click()
    driver.implicitly_wait(10)
    driver.close()
    driver.quit()


my_search=testsearch_()
print("Sucessfully Excecuted")




