package com.hamsadharani1;

import java.io.File;
import java.io.IOException;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;



public class amazonTesting {



	public static void main(String[] args) throws IOException {


System.setProperty("webdriver.chrome.driver.","C:\\Users\\chennai.support\\eclipse-workspace\\com.hamsadharani1\\driver\\chromedriver.exe");


//Resize webpage


WebDriver  driver = new ChromeDriver();
driver.manage().window().setSize(new Dimension(800,650));
driver.manage().window().setPosition(new Point(0,0));

//Screenshot code 

TakesScreenshot scrShot =((TakesScreenshot)driver);
File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
File DestFile=new File("C:\\Users\\chennai.support\\eclipse-workspace\\com.hamsadharani1\\output.png");
FileUtils.copyFile(SrcFile, DestFile);



//To maximize the window
driver.manage().window().maximize();


//To launch amazon

driver.get("https://www.amazon.in/?ie=UTF8&tag=googinabkvernac-21&ascsubtag=_k_EAIaIQobChMItoz30ubP5AIVAwqRCh0BIgYzEAAYASAAEgJZ5_D_BwE_k_&ext_vrnc=hi&gclid=EAIaIQobChMItoz30ubP5AIVAwqRCh0BIgYzEAAYASAAEgJZ5_D_BwE");
String title = driver.getTitle();
System.out.println(title);

//To Search for mobail

WebElement All = driver.findElement(By.id("searchDropdownBox"));
Select Moba = new Select(All);
Moba.selectByVisibleText("Electronics");

driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobiles");
driver.findElement(By.className("nav-input")).click();

driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/div/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")).click();

String Parent = driver.getWindowHandle();
 Set<String> windowHandles = driver.getWindowHandles();


System.out.println(Parent);
System.out.println(windowHandles);

for (String childwindow : windowHandles) {
	if(!childwindow.equals(windowHandles)) {
		
		driver.switchTo().defaultContent();
	}
	
	
	
}
















	}

}
