import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonCls {

	public static void main(String[] args) {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\chennai.support\\Desktop\\Interview\\chromedriver.exe");
	WebDriver driver=new ChromeDriver();
	driver.get("https://www.amazon.in");
	driver.findElement(By.xpath("//span[text()='Hello. Sign in']")).click();
	driver.findElement(By.id("ap_email")).sendKeys("9951682004");
	driver.findElement(By.id("continue")).click();
	driver.findElement(By.id("ap_password")).sendKeys("mswapna");
	driver.findElement(By.id("signInSubmit")).click();
    driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobiles");
   driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Google Pixel 3 XL");
   driver.findElement(By.xpath("//input[@type='submit']")).click();
   JavascriptExecutor js= (JavascriptExecutor)driver;
   js.executeScript("window.scrollBy(0,250)", "");
    //driver.findElement(By.xpath("//span[contains(test(),'Google Pixel 3a ']")).click();
	//driver.findElement(By.xpath("//div[@class='sg-col-inner']")).click();
 

	driver.findElement(By.id("buybox-see-all-buying-choices-announce")).click();
    driver.findElement(By.name("submit.addToCart")).click();
   
}
	}