package interview;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class amazontest{

public static void main (String[] args) {
		WebDriver driver;

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\chennai.support\\Desktop\\Interview\\chromedriver.exe");
		 driver= new ChromeDriver();
		 driver.manage().window().maximize();
			driver.get("https://www.amazon.in/ref=nav_logo");
			// File file = new File(""); 
			 // BufferedReader br = new BufferedReader(new FileReader(file));
			  
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Google Pixel 3 XL");
			driver.findElement(By.className("nav-search-submit nav-sprite")).click();
			driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[5]/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span")).click();
			driver.findElement(By.id("buy-now-button")).click();
			driver.findElement(By.name("email")).sendKeys("user name");
			driver.findElement(By.xpath("//*[@id=\"continue\"]")).click();
			


	}

}
