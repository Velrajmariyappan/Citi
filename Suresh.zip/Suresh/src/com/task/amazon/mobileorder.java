package com.task.amazon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.Key;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class mobileorder {
	

	
	public static void main(String[] args) throws IOException, InterruptedException {
		 int commonrate = 500000;
		 String mobilerate = null;
		 int Spendmoney = 0;
		 WebDriver driver = new ChromeDriver();
		 String mobile = null;
		 System.setProperty("webdriver.gecko.driver", "C:\\Users\\chennai.support\\Desktop\\Interview\\chromedriver.exe");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		 driver.get("https://www.amazon.in/");
		 Dimension d = new Dimension(800,480);
		 driver.manage().window().setSize(d);
 		 login(driver);  
 		 for(int i=1;i<5;i++) 
 		 {
 			mobile = Inputdata(i);
 			wait1(driver, driver.findElement(By.id("twotabsearchtextbox")));
 			driver.findElement(By.id("twotabsearchtextbox")).click();
 	        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(mobile);
 	        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.ENTER);
 	        JavaScriptWait(driver);
 	        List Mobilelist = driver.findElements(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div"));
        	mobilerate =ListofMobile(driver,Mobilelist.size(),mobile);
        	Spendmoney = Integer.parseInt(mobilerate);
        	Spendmoney += Spendmoney;
 		 }
 	    	if((commonrate - Spendmoney) == 0)
 	    	{
 	    	int fixedrate = (commonrate - Spendmoney);
    		mobile = Inputdata(5);
 			wait1(driver, driver.findElement(By.id("twotabsearchtextbox")));
 			driver.findElement(By.id("twotabsearchtextbox")).click();
 	        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(mobile);
 	        driver.findElement(By.id("twotabsearchtextbox")).sendKeys(Keys.ENTER);
 	        JavaScriptWait(driver);
 	        List Mobilelist = driver.findElements(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div"));
        	mobilerate =ListofMobile(driver,Mobilelist.size(),mobile,fixedrate);
 		 }
	}
public static void login(WebDriver driver) {
	 WebElement Acc = driver.findElement(By.xpath(".//*[@id='nav-link-accountList']"));
	 WebElement Signin = driver.findElement(By.xpath(".//*[@id='nav-al-signin']"));
	 Actions action = new Actions(driver);
	 action.moveToElement(Acc).build().perform();
	 action.moveToElement(Signin).click().build().perform();
	 driver.findElement(By.id("ap_email")).clear();
	 driver.findElement(By.id("ap_email")).click();
	 driver.findElement(By.id("ap_email")).sendKeys("9677041424");
	 driver.findElement(By.id("ap_password")).clear();
	 driver.findElement(By.id("ap_password")).click();
	 driver.findElement(By.id("ap_password")).sendKeys("India@123");
	
}
public static String Inputdata(int input) throws IOException {
	BufferedReader bufReader = new BufferedReader(new FileReader("C:\\Users\\chennai.support\\Desktop\\Interview\\Citi\\input.txt"));
    ArrayList<String> listOfLines = new ArrayList<>();

    String line = bufReader.readLine();
    while (line != null) {
      listOfLines.add(line);
      line = bufReader.readLine();
    }
    String mobilelist = listOfLines.get(input);
    return mobilelist;
}
public static void wait1(WebDriver driver,WebElement element) {
	WebDriverWait wait =new WebDriverWait(driver,10);
	wait.until(ExpectedConditions.visibilityOf(element));
}
public static void JavaScriptWait(WebDriver driver) {
	JavascriptExecutor  wait1 =(JavascriptExecutor)driver;
	if (wait1.executeScript("return document.readyState").toString().equals("complete")){ 
		   System.out.println("Page Is loaded.");
	}
}
public static String ListofMobile(WebDriver driver,int mobilelist,String mobile) {
	String Mobilerate = null;
	for(int i =1;i<=mobilelist ;i++)
	{
		String Mobilename =driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]//div[@class='a-section a-spacing-medium']/div[2]/div[2]/div/div[1]//div[@class='a-section a-spacing-none']/h2")).getText();
		if(Mobilename.equalsIgnoreCase(mobile))
		{
		 Mobilerate =driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]//div[@class='a-section a-spacing-medium']/div[2]/div[2]/div/div[2]//div[@class='a-section a-spacing-none a-spacing-top-small']")).getText();
		 driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]")).click();
		 openInNewTabAndSwitch(driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]")),driver);
		 driver.findElement(By.id("buy-now-button")).click();
		 break;
		}
	}
		return Mobilerate;
}
public static void openInNewTabAndSwitch(WebElement linkElement,WebDriver driver) 
{
    String parentTab = driver.getWindowHandle();
    Actions newTab = new Actions(driver);
    newTab.keyDown(Keys.CONTROL).click(linkElement).keyUp(Keys.CONTROL).build().perform();
    WebDriverWait wait = new WebDriverWait(driver,5);
    wait.until(ExpectedConditions.numberOfWindowsToBe(2));
    Set<String> windowSet = driver.getWindowHandles();
    for(String tab:windowSet)
    {
        if(!parentTab.equalsIgnoreCase(tab))
        {
            driver.switchTo().window(tab);
        }
    }
}
public static String ListofMobile(WebDriver driver,int mobilelist,String mobile,int fixedrate) {
	String Mobilerate = null;
	int Spendmoney =0;
	for(int i =1;i<=mobilelist ;i++)
	{
		String Mobilename =driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]//div[@class='a-section a-spacing-medium']/div[2]/div[2]/div/div[1]//div[@class='a-section a-spacing-none']/h2")).getText();
		if(Mobilename.equalsIgnoreCase(mobile))
		{
		 Mobilerate =driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]//div[@class='a-section a-spacing-medium']/div[2]/div[2]/div/div[2]//div[@class='a-section a-spacing-none a-spacing-top-small']")).getText();
		 Spendmoney = Integer.parseInt(Mobilerate);
		 if(Spendmoney <= fixedrate)
		 {
			 driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]")).click();
			 openInNewTabAndSwitch(driver.findElement(By.xpath("//*[@class='sg-row']/div[2]//div[@class='s-result-list s-search-results sg-row']/div["+mobilelist+"]")),driver);
			 driver.findElement(By.id("buy-now-button")).click();
			 break;
		 }
		}
	}
		return Mobilerate;
}
}
