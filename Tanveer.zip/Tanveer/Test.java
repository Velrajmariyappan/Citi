import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		
		  String file = "C:\\Users\\chennai.support\\Desktop\\Interview\\Citi\\input.txt";
		  FileReader fr = new FileReader(file);
		  
		  BufferedReader br = new BufferedReader(fr); String Content ="";
		  while((Content =br.readLine())!= null)
		  
		  { System.out.println(Content);
		  
		  }
		 
	System.setProperty("webdriver.chrome.driver","C:\\Users\\chennai.support\\Desktop\\Interview\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://www.amazon.in");
	
	WebElement Mobiles = driver.findElement(By.id("twotabsearchtextbox"));
	
			Mobiles.sendKeys("Mobile");
WebElement Search =driver.findElement(By.xpath("//*[@id=\"nav-search\"]/form/div[2]/div/input"));
Search.click();
;
WebElement AppleIphone = driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[2]/div/span[3]/div[1]/div[1]/div/div/div/div/div/div[2]/div[2]/div/div[1]/div/div/div[1]/h2/a/span"));
AppleIphone.click();





Set<String> ids = driver.getWindowHandles();
Iterator<String> it = ids.iterator();
String parentId = it.next();
String childId = it.next();
driver.switchTo().window(childId);

WebElement Buy=driver.findElement(By.xpath("//*[@id='submit.buy-now']/span"));
Buy.click();

driver.findElement(By.xpath("//*[@id='ap_email']")).sendKeys("9884441680");
driver.findElement(By.xpath("//*[@id='continue']")).click();

driver.findElement(By.xpath("//*[@id='ap_password']")).sendKeys("India@123");
		driver.findElement(By.xpath("//*[@id='signInSubmit']")).click();
		
		

		
		  driver.switchTo().defaultContent();
		  FileWriter fw=new FileWriter("C:\\Users\\chennai.support\\Desktop\\Interview\\Citi\\output.txt" );
		  
		  BufferedWriter bw=new BufferedWriter(fw); bw.write("AppleIphone;59,900,1");
		  bw.close();
		 
	
	}
	
	
}
		
		// TODO Auto-generated method stub

	

	
