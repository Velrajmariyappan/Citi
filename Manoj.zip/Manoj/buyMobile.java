package Manoj;

import java.io.BufferedReader;
import java.io.File;

import java.io.FileReader;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class buyMobile {
	
	static WebDriver   driver;
	static String selectmobile ="OnePlus 7 Pro (Nebula Blue, 8GB RAM, 256GB Storage)";
	
	
public static void main(String [] args) throws IOException{

      launchBrowser();
      searchProduct("OnePlus 7", selectmobile);
}


// browser Launch
	public static void launchBrowser() {
	
	System.setProperty("webdriver.chrome.driver","C:\\Users\\chennai.support\\Desktop\\chrome\\chromedriver.exe");
	
	driver= new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.get("https://www.amazon.in/");
	
	 
}
	///Description -- This method Excute all till maximum amont reaches
	public static void searchProduct(String brandOfMobile, String choosewithPrice) throws IOException {
		String maxamount ="500000";
		
		WebElement verifyPage = driver.findElement(By.xpath("//span[@class='nav-sprite nav-logo-base']"));
		 if(verifyPage.isDisplayed()) {
		 	 System.out.println("SuceessFullyNavigated Amazon HomePage");
		   String amazonSearchFiled =  driver.findElement(By.id("twotabsearchtextbox")).getText();
		   if(amazonSearchFiled.isEmpty()) {
			   driver.findElement(By.id("twotabsearchtextbox")).sendKeys(brandOfMobile);
			   driver.findElement(By.xpath("//input[@class='nav-input']/parent::div/span")).submit();
			   driver.findElement(By.xpath("//span[text()='OnePlus 7 Pro (Nebula Blue, 8GB RAM, 256GB Storage)']")).click();;
			    driver.findElement(By.id("add-to-cart-button")).click();
                driver.findElement(By.id("hlb-view-cart-announce")).click();
                String  price = driver.findElement(By.xpath("//span[@id='sc-subtotal-amount-activecart']/span")).getText();
                for(int i=0;i<maxamount.length();i++) { 
                if(!(maxamount==price)) {
                	 driver.findElement(By.id("twotabsearchtextbox")).sendKeys(brandOfMobile);
                	 driver.findElement(By.id("twotabsearchtextbox")).sendKeys(brandOfMobile);
                	 driver.findElement(By.id("twotabsearchtextbox")).sendKeys(brandOfMobile);
                }
                }
		   }
		 }
        			 
                	
                
	}
	
	
//  this method Read TextFile and retun MOBILEBrandName
	
	
	
	
	
	public static String readTxtFile(String MobileName) throws IOException {
		 String cLine ="";
		String path ="C:\\Users\\chennai.support\\Desktop\\Interview\\Citi\\input.txt";
		File txtFile = new File(path);
		if(txtFile.exists()) {
		      FileReader filereader = new  FileReader(txtFile);
			BufferedReader reader = new BufferedReader(filereader);   
			while ((cLine=reader.readLine())!=null) {
				if(cLine.equals(MobileName)) {		
					     
				}
				
			}
		}
		return cLine;
	}

	
	
	
	
}