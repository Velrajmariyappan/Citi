package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Test1 
{

	public static <webelement> void main(String[] args) throws InterruptedException 
	{
		System.setProperty("Webdriver.Chrome.Driver","\\C:\\Users\\CHENNA~1.SUP\\AppData\\Local\\Temp\\chromedriver_win32.zip\\ChromeDriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http:\\www.amazon.com");
		driver.manage().window().maximize();
		driver.manage().window().setPosition(new Point(0,-1000));
		driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		String str=driver.findElement(By.xpath("//input[@type='text']")).getText();
		System.out.println(str);
		driver.findElement(By.xpath("//input[@value='Go']")).click();
		driver.findElement(By.id("email")).sendKeys("vanisribe@gmail.com");
		driver.findElement(By.name("pass")).sendKeys("31101989");
		driver.findElement(By.linkText("forgotaccount?"));
		driver.findElement(By.xpath("//input[@id='continue']")).click();
		driver.findElement(By.xpath("//input[@value='mobilesamsung m10']"));
		driver.findElement(By.xpath("//span[@class='a-price-whole']"));
		WebElement e=driver.findElement(By.xpath("//select[@title='Search in']"));
		WebDriverWait wait=new WebDriverWait(driver,10);
		Actions act=new Actions(driver);
		act.contextClick(e).sendKeys(Keys.ARROW_DOWN,Keys.ARROW_DOWN,Keys.ENTER).perform();
		act.contextClick(e).build().perform();
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window,scrollby(0,1000)");
		Thread.sleep(2000);
		driver.close();

	}

}
