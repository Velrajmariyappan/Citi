package gadgets;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Mobiles {
	
public static void main(String [] args) {
		
		System.setProperty("webdriver.chromedriver.driver","C:\\Users\\chennai.support\\Desktop\\Anusha\\New\\driver\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in");
		
		WebElement s=driver.findElement(By.id("nav-link-accountList"));
		s.click();
		
		WebElement u=driver.findElement(By.xpath("//input[@type='email']"));
		u.sendKeys("8667670078");
		
		WebElement b1=driver.findElement(By.xpath("//input[@type='submit']"));
		b1.click();
		
		WebElement p=driver.findElement(By.xpath("//input[@type='password']"));
		p.sendKeys("8667670078");
		
		WebElement b2=driver.findElement(By.id("signInSubmit"));
		b2.click();
		
		WebElement sb=driver.findElement(By.id("twotabsearchtextbox"));
		sb.sendKeys("Google Pixel 3 XL");
		
		WebElement sb1=driver.findElement(By.xpath("//input[@tabindex='10']"));
		sb1.click();
		
		WebElement ph=driver.findElement(By.xpath("//span[@class='a-size-medium a-color-base a-text-normal'][1]"));
		ph.click();
		
		WebElement b5=driver.findElement(By.xpath("//input[@title='Add to Shopping Cart']"));
		b5.click();
}
}

