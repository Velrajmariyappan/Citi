package Project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UseCase {

	WebDriver driver = null;

	@BeforeEach
	void setUp() throws Exception {

		// Setting the Property of Chrome Driver to Chrome Driver path in local Machine

		System.setProperty("webdriver.chrome.driver",
				"E://Sahithi_QA_Workspace//Material//JarFilesNeeded//chromedriver.exe");

		// Intializing the chromedriver
		driver = new ChromeDriver();

		// Invoking the Required URL using Get Method
		driver.get("https://www.amazon.in/");

		// Maximizing the window (In the sense changing the window size and position to
		// cover the right half of the screen)
		driver.manage().window().maximize();

		// Implicitly wait is used to tell the webdriver to wait for certain amount of
		// time until all the Web Elements got loaded properly
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@AfterEach
	void tearDown() throws Exception {

		// In order to close all browser windows
		driver.quit();
	}

	@Test
	void test() throws IOException {

		// List to store Mobile Names
		List<String> mobileNames = new ArrayList<String>();

		// TO read data from input file
		FileReader freader = new FileReader("E://Sahithi_QA_Workspace//input.txt");

		// To read Data from another reader 
		BufferedReader br = new BufferedReader(freader);
		String x = "";
		while ((x = br.readLine()) != null) {
			System.out.println(x + "\n");
			//Adding mobile Names to a list
			mobileNames.add(x);
		}
		//Printing Mobile Names 
		System.out.println("Mobile Names From input file are :" + mobileNames.toString());
		br.close();

		//Hashmap to store Mobile Name as Key with Price as Value
		HashMap<String, String> mobileMap = new HashMap<>();
		
		//To store Mobile Prices in a list
		List<String> mobilePrices = new ArrayList<String>();
		
		//For loop to iterate through all mobiles
		for (String mName : mobileNames) {
			
			//To Navigate to Amazon.in
			driver.navigate().to("https://www.amazon.in/");
			
			//To enter each Mobile Name in search box
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys(mName);
			
			//To click on Search Button
			driver.findElement(By.xpath("//input[@type='submit' and @value='Go']")).click();
			System.out.println("Mobile Webelement is "
					+ "(//span[@class='a-size-medium a-color-base a-text-normal' and contains(text(),'" + mName
					+ "')])[1]");
			
			//To click on First Link for that Mobile Name Searched
			driver.findElement(
					By.xpath("(//span[@class='a-size-medium a-color-base a-text-normal' and contains(text(),'" + mName
							+ "')])[1]"))
					.click();
			
			//In order to get Price we need to switch to particular window
			Set<String> handles = driver.getWindowHandles();
			for (String window : handles) {
				driver.switchTo().window(window);
			}
			WebElement priceElement = driver.findElement(By.xpath("//span[@id='priceblock_ourprice']"));
			
			//To get the price
			String price = priceElement.getText();
			System.out.println(price.substring(2));
			//Storing all Mobile Prices to a list
			mobilePrices.add(price.substring(2));
			//Storing MobileNames with Prices in a hashMap
			mobileMap.put(mName, price.substring(2).replaceAll(",", ""));
		}

		System.out.println(mobilePrices.toString());
		System.out.println(mobileMap.toString());
		
		
		//Logic to buy mobiles with maximum types followed by maximum number of mobiles
		double sum = 0.00;
		int iPhoneCount = 0;
		int onePlusCount = 0;
		int nokiaCount = 0;
		int googlePixelCount = 0;
		int samsungGalaxyCount = 0;
		mobileMap=sortByValue(mobileMap);
		
		System.out.println(mobileMap.toString());
		
		while (sum < 5000000.00) {
			for (Map.Entry<String, String> entry : mobileMap.entrySet()) {

				double value = Double.parseDouble(entry.getValue());
				System.out.println("values is" + value);
				if (entry.getKey().trim().equals("Nokia 8.1")) {
					sum += value;
					if (sum < 5000000.00) {
						nokiaCount = nokiaCount + 1;
					}

					System.out.println("Nokia");

				} else if (entry.getKey().trim().equals("OnePlus 7")) {
					sum += value;
					System.out.println("Oneplus");
					if (sum < 5000000.00) {
						onePlusCount = onePlusCount + 1;
					} 

				} else if (entry.getKey().trim().equals("Google Pixel 3 XL")) {
					sum += value;
					System.out.println("Google");
					if (sum < 5000000.00) {
						googlePixelCount = googlePixelCount + 1;
					} 

				} else if (entry.getKey().trim().equals("Apple iPhone XR")) {
					sum += value;
					System.out.println("Apple");
					if (sum < 5000000.00) {
						iPhoneCount = iPhoneCount + 1;
					} 
				} else if (entry.getKey().trim().equals("Samsung Galaxy Note 10")) {
					sum += value;
					System.out.println("Samsung");
					if (sum < 5000000.00) {
						samsungGalaxyCount = samsungGalaxyCount + 1;
					} else {
						break;
					}

				}
			}
System.out.println("Sum"+sum);
		}
		
		
		//Writing data to a text file
		FileWriter fw=new FileWriter("E://Sahithi_QA_Workspace//SeleniumUseCase.txt");
		BufferedWriter bw=new BufferedWriter(fw);
		
		
		for ( String key : mobileMap.keySet() ) {
			if(key.equals("Nokia 8.1")) {
				bw.write(key+";"+mobileMap.get(key)+";"+nokiaCount);
			}else if(key.equals("OnePlus 7")) {
				bw.write(key+";"+mobileMap.get(key)+";"+onePlusCount);
			}else if(key.equals("Google Pixel 3 XL")) {
				bw.write(key+";"+mobileMap.get(key)+";"+googlePixelCount);
			}else if(key.equals("Apple iPhone XR")) {
				bw.write(key+";"+mobileMap.get(key)+";"+iPhoneCount);
			}else if(key.equals("Samsung Galaxy Note 10")){
				bw.write(key+";"+mobileMap.get(key)+";"+samsungGalaxyCount);
			}
			bw.newLine();
		}
		
		
		bw.close();

	}
	
	// function to sort hashmap by values 
    public static HashMap<String, String> sortByValue(HashMap<String, String> hm) 
    { 
        // Create a list from elements of HashMap 
        List<Entry<String, String>> list = 
               new LinkedList<Map.Entry<String, String> >(hm.entrySet()); 
  
        // Sort the list 
        Collections.sort(list, new Comparator<Map.Entry<String, String> >() { 
            public int compare(Map.Entry<String, String> o1,  
                               Map.Entry<String, String> o2) 
            { 
                return (o1.getValue()).compareTo(o2.getValue()); 
            } 
        }); 
          
        // put data from sorted list to hashmap  
        HashMap<String, String> temp = new LinkedHashMap<String, String>(); 
        for (Map.Entry<String, String> aa : list) { 
            temp.put(aa.getKey(), aa.getValue()); 
        } 
        return temp; 
    } 
}
